<?php
function zilla_support_page() { ?>
    <script type="text/javascript">
        //<![CDATA[
            window.location.replace("http://themezilla.com/support");
        //]]>
    </script>
<?php }
