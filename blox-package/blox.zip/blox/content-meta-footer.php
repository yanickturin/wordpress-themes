<!--BEGIN .entry-meta .entry-footer-->
<div class="entry-meta entry-footer">
	<span class="entry-categories"><?php _e('Posted in: ', 'zilla') ?> <?php the_category(', ') ?></span>
    <span class="entry-tags"><?php the_tags( ' / ' . __('Tagged:', 'zilla') . ' ', ', ', ''); ?></span>
<!--END .entry-meta .entry-footer-->
</div>